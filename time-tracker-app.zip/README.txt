راهنمای نصب - ثبت ساعت کار

روش ۱ (ساده، بدون اینترنت): فایل index.html را با Chrome یا Edge باز کنید.
  برای دسترسی سریع: Chrome > سه‌نقطه > Cast, save and share > Create shortcut (تیک Open as window).

روش ۲ (نصب واقعی به‌صورت اپلیکیشن): پوشه را روی یک هاست HTTPS بگذارید
  (مثلا Netlify Drop، GitHub Pages یا Cloudflare Pages). سپس در Chrome/Edge آیکون Install
  کنار نوار آدرس ظاهر می‌شود؛ در گوشی: Add to Home screen.
  بعد از نصب، اپ آفلاین هم کار می‌کند.

توجه: داده‌ها در مرورگر/اپ همان دستگاه ذخیره می‌شوند. فایل اکسل ماه را مرتب دریافت کنید.
